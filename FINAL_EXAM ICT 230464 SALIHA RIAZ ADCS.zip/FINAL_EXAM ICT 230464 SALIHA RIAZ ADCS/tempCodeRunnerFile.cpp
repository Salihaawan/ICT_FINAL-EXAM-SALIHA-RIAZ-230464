#include <iostream>
#include <cmath>

using namespace std;

// Function to left shift the digits of a number
int leftShift(int num, int shiftCount) {
    int digits = log10(num) + 1;
    shiftCount = shiftCount % digits;

    int divisor = pow(10, shiftCount);
    int leftPart = num / divisor;
    int rightPart = num % divisor;

    return (rightPart * pow
